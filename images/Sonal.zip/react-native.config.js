module.exports = {
    project: {
        ios: {},
        android: {}
    },
    assets: ['./src/commonCSS/Montserrat', './src/commonCSS/Inter', './src/commonCSS/poppins'],
}

// npx react-native-asset