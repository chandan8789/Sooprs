const constants = Object.freeze({
  BASE_URL: 'http://3.7.216.224:3000/',

  MOB_ACCESS_TOKEN_KEY: "accessToken",
  USER_ID_KEY: "user_Id",
  IS_LOGIN: "is_login",

  // splash
  splashText: 'Dawai Bazar',



  // maps
  MapApiKey: 'AIzaSyAyu-6Pv7RaiohWH1bWpQqwXbx7roNG_GA',
  GOOGLE_PACES_API_BASE_URL: 'https://maps.googleapis.com/maps/api/place',


  // api

  // login
  loginApi: 'auth/login',
  verifyOtp: 'auth/verify-otp',

  // attendence
  attendenceCheckIn: 'attendance/checkin',
  attendenceCheckOut: 'attendance/checkin',
  getAttendance: 'attendance/records',

  //route 
  getTodaysRoute: 'route/today',
  // getCurrentweekTask: 'route/week',
  getMonthTask: 'route/month',
  getCustomTask: 'route/custom',
  // task:
  yourTask: 'task/view',













})

export default constants;