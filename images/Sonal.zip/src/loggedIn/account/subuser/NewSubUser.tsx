import React, {useEffect, useState} from 'react';
import {
	Alert,
	Image,
	ScrollView,
	StyleSheet,
	Text,
	TextInput,
	TouchableOpacity,
	View,
} from 'react-native';
import {
	heightPercentageToDP as hp,
	widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import FontSize from '../../../commonCSS/FontSize';
// import FontSize from '../../../../theme/FontSize';

export default function NewSubUser({route, navigation}) {

	const pattern =
		/[a-zA-Z0-9]+[\.]?([a-zA-Z0-9]+)?[\@][a-z]{3,9}[\.][a-z]{2,5}/;

	const [userName, setUserName] = useState('');
	const [firstName, setFirstName] = useState('');
	const [lastName, setLastName] = useState('');
	const [email, setEmail] = useState('');

	const [countryCode, setCountryCode] = useState('+358');
	const [initialCountryCode, setInitialCountryCode] = useState('');
	const [phone, setPhone] = useState('');
	const [ph, setPh] = useState('');

	const [password, setPassword] = useState('');
	const [confirmPassword, setConfirmPassword] = useState('');

	const [status, setStatus] = useState(false);


	useEffect(() => {
		if(route.params !== undefined) {
			setStatus(true);
			setUserName(route.params.username)
			setFirstName(route.params.first_name)
			setLastName(route.params.last_name)
			setEmail(route.params.email)

			setCountryCode(route.params.country_code)
			setInitialCountryCode(route.params.country_code);

			setPhone(route.params.phone)
			setPh('')
		}
	}, [])
	// /////////////////////////////////////////////////////////////new subuser





	const CreateUser = () => {
		if(
			userName == '' ||
			firstName == '' ||
			lastName == '' ||
			email == '' ||
			ph == '' ||
			password == '' ||
			confirmPassword == ''
		) {
			// setMessage(
			// 	// 'Please Enter Details'
			// 	Lang && Object.keys(Lang).length > 0 ? Lang[ln]?.new['Please Enter Details'] : ''
			// );
			setApplyModal(true);
		} else if(pattern.test(email) === false) {
			// setMessage(
			// 	// 'Please Enter valid Email'
			// 	Lang && Object.keys(Lang).length > 0 ? Lang[ln]?.new['Please Enter valid Email'] : ''

			// );
			setApplyModal(true)
		}
		else if(password.length <= 8) {
			// setMessage(
			// 	// 'Passwords should be a minimum of eight characters in length'
			// 	Lang && Object.keys(Lang).length > 0 ? Lang[ln]?.new['Passwords should be a minimum of eight characters in length'] : ''
			// );
			setApplyModal(true)
		}
		else if(confirmPassword.length <= 8) {
			// setMessage(
			// 	// 'Please Confirm Your Password'
			// 	Lang && Object.keys(Lang).length > 0 ? Lang[ln]?.new['Please Confirm Your Password'] : ''
			// );
			setApplyModal(true)
		}
		else if(password !== confirmPassword) {
			// setMessage(
			// 	// 'Password Does Not Match'
			// 	Lang && Object.keys(Lang).length > 0 ? Lang[ln]?.new['Password Does Not Match'] : ''
			// );
			setApplyModal(true)
		} else {
			let bodyData = {
				country_code: countryCode,
				username: userName,
				first_name: firstName,
				last_name: lastName,
				email: email,
				phone: countryCode + ph,
				password: password,
				confirm_password: confirmPassword
			};
			console.log('BodyDataaa===>', bodyData);

			// 	postDataWithToken(bodyData, Constant.end_Point.SUBUSER)
			// 		.then(res => {
			// 			if(res.status_code === 200) {
			// 				console.log('reeeeeeessssssssaaapppp', res)
			// 				console.log('jkfkjhasdjkfhsakfjhask', res.message);
			// 				setMessage(res.message);
			// 				setApplyModalb(true)
			// 			} else {
			// 				console.log("fasdasfgagadgagafsaff", res.error_message);
			// 				setMessage(res.error_message);
			// 				setApplyModal(true)
			// 			}
			// 		})
			// 		.catch(error => {});
		}
	};

	// --------------------------update Location api call --------------------------\\
	const updateSubuser = () => {

		// if(
		// 	userName == '' ||
		// 	firstName == '' ||
		// 	lastName == '' ||
		// 	email == '' ||
		// 	phone == '' ||
		// 	password == '' ||
		// 	confirmPassword == ''
		// ) {
		// 	setMessage(Lang && Object.keys(Lang).length > 0 ? Lang[ln]?.new['Please Enter Details'] : '');
		// 	setApplyModal(true)
		// } else if(pattern.test(email) === false) {
		// 	setMessage(Lang && Object.keys(Lang).length > 0 ? Lang[ln]?.new['Please Enter valid Email'] : '');
		// 	setApplyModal(true)
		// } else if(password !== confirmPassword) {
		// 	setMessage(Lang && Object.keys(Lang).length > 0 ? Lang[ln]?.new['Password Does Not Match'] : '');
		// 	setApplyModal(true)
		// } else {
		// 	let request = {
		// 		country_code: countryCode,
		// 		username: userName,
		// 		first_name: firstName,
		// 		last_name: lastName,
		// 		email: email,
		// 		phone: countryCode + ph,
		// 		password: password,
		// 		confirm_password: confirmPassword,
		// 		subuser_id: route.params.id
		// 	};
		// 	console.log("bodududuududduddddddddddd", request)
		// 	dispatch(loaderAction(true));
		// 	patchData(request, Constant.end_Point.SUBUSER)
		// 		.then(res => {
		// 			console.log('resssffere', res);
		// 			if(res.status_code === 200) {
		// 				dispatch(loaderAction(false));
		// 				// navigation.pop()
		// 				setMessage(res.detail);
		// 				setApplyModalb(true);
		// 			} else {
		// 				setMessage(res.detail);
		// 				setApplyModal(true)
		// 				dispatch(loaderAction(false));
		// 			}
		// 		})
		// 		.catch(error => {
		// 			dispatch(loaderAction(false));
		// 		});
		// };
	};

	const [message, setMessage] = useState('')
	const [applyModal, setApplyModal] = useState(false);
	const [applyModalb, setApplyModalb] = useState(false);


	return (
		// <KeyboardAwareScrollView>
		<View style={styles.main}>

			<ScrollView style={{paddingHorizontal: wp(3), marginTop: hp(2)}}>

				<View style={{flex: 1}}>
					<Text style={[styles.userDetails, {fontWeight: '700'}]}> User Details</Text>

					<View style={styles.textInputView}>
						<TextInput
							placeholderTextColor={'#96989A'}
							style={styles.placeHolderText}
							placeholder={'Enter First Name'}
							onChangeText={val => setFirstName(val)}>
						</TextInput>
					</View>

					<View style={styles.textInputView}>
						<TextInput
							placeholderTextColor={'#96989A'}
							placeholder={'Enter Last Name'}
							style={styles.placeHolderText}
							onChangeText={val => setLastName(val)}>
						</TextInput>
					</View>

					{status == true ?
						<View style={[styles.textInputView, {flexDirection: 'row', alignItems: 'center', paddingLeft: wp(2)}]}>
							<View style={{height: 20, width: 20, alignItems: 'center', }}>
								{/* <Image
									resizeMode='cover'
									style={{height: '100%', width: '100%'}}
									source={require('../../../../assets/Icon/Login/call.png')}></Image> */}
							</View>
							<Text style={{color: 'black'}}>{phone}</Text>
						</View>
						:
						<View style={[styles.textInputView, {
							flexDirection: 'row', alignItems: 'center', paddingLeft: wp(2),
							justifyContent: 'center'
						}]}>
							<View style={{height: 20, width: 20, alignItems: 'center', }}>
								{/* <Image
									resizeMode='cover'
									style={{height: '100%', width: '100%'}}
									source={require('../../../../assets/Icon/Login/call.png')}></Image> */}
							</View>

							{/* <TouchableOpacity
								onPress={() => setShow(!show)}
								style={{
									alignItems: 'center',
									width: '15%',
									justifyContent: 'space-around',
								}}>
								<Text
									style={{
										fontSize: FontSize.fs13,
										color: '#333333',
									}}>
									{countryCode}
								</Text>
							</TouchableOpacity> */}

							<TextInput
								placeholderTextColor={'#96989A'}
								style={{flex: 1}}
								keyboardType="numeric"
								placeholder={'Enter Mobile Number'}
								onChangeText={val => [setPh(val), setPhone(val)]}>
							</TextInput>



							{/* <CountryPicker onBackdropPress={() => setShow(false)}
								// inputPlaceholder={'country'}
								// searchMessage={'Some search message here'}
								style={{
									// Styles for whole modal [View]
									modal: {
										height: hp(55),
										// backgroundColor: 'red'
									},
								}}
								show={show}
								// when picker button press you will get the country object with dial code
								pickerButtonOnPress={item => {
									console.log('item>>>>>', item);
									setCountryCode(item.dial_code);
									// handleInputChange('country_code', item.dial_code);
									setShow(false);
								}}
							/> */}
							{/* </View> */}
						</View>
					}




					<View style={styles.textInputView}>
						<TextInput
							placeholderTextColor={'#96989A'}
							style={styles.placeHolderText}
							//   secureTextEntry
							placeholder={'Enter Password'}
							onChangeText={val => setPassword(val)}>
						</TextInput>
					</View>

					<View style={styles.textInputView}>
						<TextInput
							placeholderTextColor={'#96989A'}
							style={styles.placeHolderText}
							//   secureTextEntry
							placeholder={'Confirm Password'}
							onChangeText={val => setConfirmPassword(val)}>
						</TextInput>
					</View>
				</View>
			</ScrollView >

			<View
				style={{
					justifyContent: 'center',
					alignItems: 'center',
					flex: 1,
					marginVertical: hp(5),
				}}>
				{/* btn */}
				{route.params !== undefined ?
					<TouchableOpacity
						style={styles.btnBackGround}
						onPress={() => updateSubuser()}>
						<Text style={styles.btnText}>  {'Update Sub User'}</Text>
					</TouchableOpacity>
					:
					<TouchableOpacity
						style={styles.btnBackGround}
						onPress={() => CreateUser()}>
						<Text style={styles.btnText}>  {'Create Sub User '}</Text>
					</TouchableOpacity>}

			</View>

			{/* <Loader val={loaderResponse.loader} /> */}

			{/* <SuccessModal
					single={true}
					visible={applyModal}
					onRequestClose={() => setApplyModal(false)}
					message={message}
					onPressOk={() => setApplyModal(false)}
				/> */}

			{/* go back */}
			{/* <SuccessModal
					single={true}
					visible={applyModalb}
					onRequestClose={() => setApplyModalb(false)}
					message={message}
					onPressOk={() => [setApplyModalb(false), navigation.goBack()]}
				/> */}
		</View >
		// </KeyboardAwareScrollView>
	);
}

const styles = StyleSheet.create({
	main: {
		backgroundColor: '#FFFFFF',
		flex: 1,
	},
	userDetails: {
		color: '#444444',
		fontFamily: 'Poppins-Regular',
		fontWeight: '500',
		fontSize: FontSize.fs1,
		lineHeight: 22,
		marginVertical: hp(1),
	},
	btnBackGround: {
		backgroundColor: '#1374DF',
		height: hp(5),
		// width: 332,
		// flex:1,
		width: wp(55),
		borderRadius: hp(10),
		justifyContent: 'center',
	},
	btnText: {
		color: '#FFFFFF',
		textAlign: 'center',
		fontFamily: 'Poppins-Regular',
		fontWeight: '400',
		fontSize: FontSize.fs16,
	},

	textInputView: {
		marginTop: hp(1.8),
		// height: 40,
		height: hp(6),
		// alignItems: 'center',
		backgroundColor: '#FFF',

		borderWidth: 1,
		borderColor: '#D2D2D2',
		borderRadius: hp(1),
	},
	placeHolderText: {
		// top: 2,
		flex: 1,
		color: '#000',
		paddingLeft: wp(5),
		fontFamily: 'Poppins-Regular',
		justifyContent: 'center',
		fontSize: FontSize.fs15,
		fontWeight: '400',
		alignItems: 'center',
		paddingTop: hp(1)

	},
});

