import React, {useState} from 'react';
import {View, Text, ScrollView, TouchableOpacity, StyleSheet} from 'react-native';
import {commonCSS, hp} from '../../commonCSS/GlobalCss';
import HeaderCustom from '../../component/HeaderCustom';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {Colors} from '../../commonCSS/Colors';
import CustomTextInput from '../../component/custom/CustomTextInput';
import ModalSuccess from '../../component/ModalSuccess';
import Button from '../../component/Button';
import FontSize from '../../commonCSS/FontSize';
import Font from '../../commonCSS/Font';
import AccordianDealInfo from './comp/AccordianDealInfo';
import {Images} from '../../assets';

export default function CreateDeal({navigation}: {navigation: any}) {
    const [newDealData, setNewDealData] = useState({
        orginationName: '',
        phone: '',
        email: '',
    });
    const [errMessage, setErrMessage] = useState('');
    const [errModalVisible, setErrModalVisible] = useState(false);

    const validateEmail = (email: string) => {
        return email.match(
            /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        );
    };

    const createDeal = () => {
        if(newDealData.orginationName === '') {
            setErrMessage('Please enter Orgination Name')
            setErrModalVisible(true);
            return;
        }
        if(newDealData.phone === '') {
            setErrMessage('Please enter Phone Number')
            setErrModalVisible(true);
            return;
        }
        if(newDealData.phone.length < 10 || newDealData.phone.length > 10) {
            setErrMessage('Please enter a valid Phone Number')
            setErrModalVisible(true);
            return;
        }
        if(newDealData.email === '') {
            setErrMessage('Please enter Email Address')
            setErrModalVisible(true);
            return;
        }
        if(!validateEmail(newDealData.email)) {
            setErrMessage("Please Enter a Valid Email");
            setErrModalVisible(true);
            return;
        }

    }

    return (
        <View style={{...commonCSS.bodyFAFAFA}}>
            <HeaderCustom
                title={'Add New Medicine'}
                onPressBackArrow={() => navigation.goBack()}
                button={false}
                onPressButton={undefined}
                btnText={''} isSearchAvailable={false} searchKeyword={''} onchangeText={undefined} />

            <KeyboardAwareScrollView contentContainerStyle={{flex: 1, ...commonCSS.pvh}}>
                <ScrollView style={{}}>

                    {/* <View style={{...commonCSS.fdralic, justifyContent: 'space-between', }}>
                        <View></View>
                        <TouchableOpacity
                            onPress={() => {}}>
                            <Text style={{...commonCSS.titleMB70016, color: Colors.ThemeColorDark}}>Reschedule Visit</Text>
                        </TouchableOpacity>
                    </View> */}

                    <CustomTextInput
                        title={'Medicine Name'}
                        placeholder={'Medication Name Here'}
                        multiline={false}
                        value={newDealData.orginationName}
                        onChangeText={(val => {
                            setNewDealData(prevData => ({
                                ...prevData,
                                orginationName: val
                            }));
                        })}
                        marginTop={false}
                        keyboardTypes={undefined}
                        placeholderTextColor={Colors.secondaryText94}
                        disabled={false}
                    />
                    <CustomTextInput
                        title={'Medicine Price'}
                        placeholder={'123'}
                        multiline={false}
                        value={newDealData.phone}
                        onChangeText={(val => {
                            setNewDealData(prevData => ({
                                ...prevData,
                                phone: val
                            }));
                        })}
                        marginTop={true}
                        keyboardTypes={'number-pad'}
                        placeholderTextColor={Colors.secondaryText94}
                        disabled={false}
                    />

                    {/* <CustomTextInput
                        title={'Email ID'}
                        placeholder={'xyz.organisation@gmail.com'}
                        multiline={false}
                        value={newDealData.email}
                        onChangeText={(val => {
                            setNewDealData(prevData => ({
                                ...prevData,
                                email: val
                            }));
                        })}
                        marginTop={true}
                        keyboardTypes={undefined}
                        placeholderTextColor={Colors.secondaryText94}
                    /> */}

                    {/* <View style={{marginTop: hp(1)}}>
                        <AccordianDealInfo label={'Lead Details'} labelImage={Images.leadx} />
                    </View> */}

                    {/* <View style={{marginTop: hp(1)}}>
                        <AccordianDealInfo label={'Deal'} labelImage={Images.deal} />
                    </View> */}

                    <View style={{marginTop: hp(2.5), ...commonCSS.alicjc}}>
                        <Button
                            label={'Add NEW MEDICINE'}
                            labelSize={FontSize.fs15}
                            fontWeight={'700'}
                            textColor={Colors.white}
                            fontFamily={Font.MontserratBlack}
                            marginLeft={''}
                            paddingHorizontal={''}
                            paddingVertical={''}
                            onPress={() => {}}
                            width={'92'}
                            backgroundColor={Colors.ThemeColorDark}
                            isButtonDisabled={false}
                            btnHeight={'5.5'}
                            borderRadius={'1.5'}
                            borderColor={''}
                            borderwidth={''}
                        />
                    </View>


                    {/* <TouchableOpacity
                        onPress={() => {}}
                    >
                        <Text style={style.tml}>Mark As Junk</Text>
                    </TouchableOpacity> */}

                </ScrollView>
            </KeyboardAwareScrollView>

            <ModalSuccess
                message={errMessage}
                visible={errModalVisible}
                onRequestClose={() => {
                    setErrModalVisible(false);
                }}
                onPress={() => {
                    setErrModalVisible(false);
                }}
            />
        </View>
    );
}

const style = StyleSheet.create({
    tml: {
        fontFamily: Font.InterBold,
        fontSize: FontSize.fs14,
        fontWeight: '700',
        color: Colors.mainText,
        textAlign: 'center',
        marginTop: hp(1.5)
    }
})
