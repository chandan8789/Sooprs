export default {

    // montser rat

    MontserratBlack: 'Montserrat-Black.ttf',
    MontserratBlackItalic: 'Montserrat-BlackItalic.ttf',

    MontserratBold: 'Montserrat-Bold.ttf',
    MontserratBoldItalic: 'Montserrat-BoldItalic.ttf',

    MontserratExtraBold: 'Montserrat-ExtraBold.ttf',
    MontserratExtraBoldItalic: 'Montserrat-ExtraBoldItalic.ttf',

    MontserratExtraLight: 'Montserrat-ExtraLight.ttf',
    MontserratExtraLightItalic: 'Montserrat-ExtraLightItalic.ttf',

    Montserratitalic: 'Montserrat-Italic.ttf',
    MontserratLight: 'Montserrat-Light.ttf',
    MontserratLightItalic: 'Montserrat-LightItalic.ttf',

    MontserratMedium: 'Montserrat-Medium.ttf',
    MontserratMediumItalic: 'Montserrat-MediumItalic.ttf',

    MontserratRegular: 'Montserrat-Regular.ttf',
    MontserratSemiBold: 'Montserrat-SemiBold.ttf',
    MontserratSemiBoldItalic: 'Montserrat-SemiBoldItalic.ttf',

    MontserratThin: 'Montserrat-Thin.ttf',
    MontserratThinItalic: 'Montserrat-ThinItalic.ttf',


    // Inter
    InterBlack: 'Inter-Black.ttf',

    InterBold: 'Inter-Bold.ttf',

    InterExtraBold: 'Inter-ExtraBold.ttf',

    InterExtraLight: 'Inter-ExtraLight.ttf',

    InterLight: 'Inter-Light.ttf',

    InterMedium: 'Inter-Medium.ttf',

    InterSemiBold: 'Inter-SemiBold.ttf',

    InterThin: 'Inter-Thin.ttf',

    // poppins
    poppinsBlack: 'Poppins-Black.ttf',
    poppinsItalic: 'Poppins-Italic.ttf',
    poppinsMedium: 'Poppins-Medium.ttf',
    poppinsRegular: 'Poppins-Regular.ttf',
    poppinsThin: 'Poppins-Thin.ttf',

    // open sans
    openSansBlack: 'OpenSans-Regular.ttf',

    // mulish
    mulish: 'Mulish-Regular.ttf',
    mulishBold: 'Mulish-Bold.ttf',
}